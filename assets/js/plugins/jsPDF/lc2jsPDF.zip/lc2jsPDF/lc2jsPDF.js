function getPDF() {
	var doc = new jsPDF();
	var subject = typeof $(".ui-collapsible-heading-toggle ui-btn ui-icon-minus ui-btn-icon-left ui-btn-inherit") !== 'undefined' ? $(".ui-collapsible-heading-toggle ui-btn ui-icon-minus ui-btn-icon-left ui-btn-inherit") : 'Content';
	var body = $(".contentbody");
	var title = document.getElementsByTagName("title")[0].innerHTML;
	
	
	var specialElementHandlers = {
		'#editor' : function(element, renderer) {
			return true;
		}
	};
	//head
	doc.setFontSize(24);
	doc.text(20, 20, 'Letztechance.org');
	doc.setFontSize(16);
	doc.text(20, 40, ''+title);
	doc.setFontSize(6);
	doc.text(20, 300, 'This is client-side Javascript PDF.');
	doc.text(20, 310, 'contact:');
	doc.text(20, 310, 'http://www.letztechance.org/contact.html');
	//content
	doc.addPage();	
	doc.setFontSize(8);
	if (typeof subject.html() !== 'undefined')
	{	
		doc.text(20, 20, '' + subject.html());
	}
	else
	{	
		doc.text(20, 20, '' + title);
	}
	
	doc.fromHTML(body.get(0), 20, 30, {
		'width' : 170,
		'elementHandlers' : specialElementHandlers
	});
	//eof content
	doc.addPage();
	//beof
	doc.setFontSize(24);
	doc.text(20, 20, 'Thank you for visiting letztechance.org.');
	//eof
	// Save the PDF
	doc.save('Letztechance.org.pdf');
}